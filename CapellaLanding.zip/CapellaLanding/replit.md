# Capella Pro - AI Productivity Suite

## Overview

Capella Pro is an AI-powered productivity suite built as a full-stack monorepo application. The project combines a React-based client application with an Express backend, featuring a separate Next.js 14 App Router landing page. The core product provides intelligent tools for task management, scheduling, finance tracking, note-taking, CRM, and collaborative workspaces.

**Tech Stack:**
- Frontend: React + Vite (main app), Next.js 14 App Router (landing page)
- Backend: Express.js with TypeScript
- Database: PostgreSQL with Drizzle ORM
- UI: shadcn/ui components with Tailwind CSS
- State Management: TanStack React Query

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Application Structure

The repository follows a monorepo pattern with three main sections:

**1. Main Application (`client/`, `server/`)**
- Client-side React application built with Vite
- Express.js backend server with session management
- Shared schema definitions and types in `shared/`
- Production build outputs to `dist/`

**2. Landing Page (`apps/landing/`)**
- Standalone Next.js 14 application using App Router
- Completely separate from main app with its own configuration
- Marketing pages: home, pricing, legal (privacy, terms, refund, cookies), contact, verification
- Designed for Razorpay payment gateway onboarding compliance

**3. Shared Resources**
- Component library using shadcn/ui with custom theming
- Tailwind configuration shared across applications
- TypeScript configuration with path aliases

### Frontend Architecture

**Main Application (React + Vite):**
- Component-based architecture using wouter for routing
- UI components from shadcn/ui in `client/src/components/ui/`
- Landing page components in `client/src/components/landing/`
- Custom hooks for mobile detection and toast notifications
- Client-side routing with wouter (NOT React Router)

**Landing Page (Next.js 14):**
- Server Components by default for better performance
- Client Components marked with "use client" directive where needed
- File-based routing in `apps/landing/app/` directory
- Reusable components in `apps/landing/components/`
- Separate styling in `apps/landing/styles/globals.css`

**Design System:**
- Custom theme extending shadcn/ui's New York style
- CSS variables for theming with HSL color format
- Responsive breakpoints: mobile-first approach
- Consistent spacing using Tailwind's spacing scale
- Custom utility classes for elevation effects (hover-elevate, active-elevate-2)

### Backend Architecture

**Server Framework:**
- Express.js with TypeScript
- HTTP server creation using Node's `http` module
- Middleware stack: JSON parsing, URL encoding, CORS handling
- Custom logging middleware with formatted timestamps

**Request Handling:**
- Route registration through `registerRoutes()` function
- API routes prefixed with `/api`
- Static file serving for production builds
- Fallback to index.html for client-side routing
- Raw body capture for webhook verification (Stripe, Razorpay)

**Development vs Production:**
- Development: Vite dev server with HMR via middleware mode
- Production: Pre-built static assets served from `dist/public`
- Hot Module Replacement on `/vite-hmr` path

**Build Process:**
- Client built using Vite
- Server bundled with esbuild
- External dependencies bundled selectively (allowlist approach)
- Reduces cold start times by minimizing file I/O syscalls

### Data Layer

**Database:**
- PostgreSQL as primary database (via environment variable `DATABASE_URL`)
- Connection pooling via Neon serverless driver (`@neondatabase/serverless`)

**ORM - Drizzle:**
- Schema definitions in `shared/schema.ts`
- Type-safe database queries
- Migrations output to `./migrations` directory
- Zod integration for runtime validation via `drizzle-zod`

**Schema Structure:**
- Users table with UUID primary keys, username, and password
- Schema exports TypeScript types for compile-time safety
- Insert schemas derived using `createInsertSchema` for validation

**Storage Interface:**
- Abstracted through `IStorage` interface in `server/storage.ts`
- In-memory implementation (`MemStorage`) for development
- Interface supports user CRUD operations
- Designed for easy swapping to database implementation

### Authentication & Session Management

**Strategy:**
- Session-based authentication (not JWT for primary auth)
- Uses `express-session` with PostgreSQL store (`connect-pg-simple`)
- Memory store fallback (`memorystore`) for development
- Passport.js integration planned (dependency present)

**Security Considerations:**
- Password hashing expected (bcrypt/argon2 not yet implemented)
- CORS configuration for cross-origin requests
- Rate limiting via `express-rate-limit`
- Session secrets should be environment variables

## External Dependencies

### Payment Processing
- **Razorpay:** Indian payment gateway integration (verification page exists at `/verification`)
- **Stripe:** Alternative payment processor (dependency installed)
- Webhook handling requires raw body parsing (implemented)

### AI Services
- **Google Generative AI:** `@google/generative-ai` package installed
- **OpenAI:** Dual AI provider support for flexibility

### UI Component Library
- **Radix UI:** Headless component primitives for accessibility
- **shadcn/ui:** Pre-styled components built on Radix
- **Lucide React:** Icon library used throughout

### Form Handling
- **React Hook Form:** Via `@hookform/resolvers`
- **Zod:** Schema validation for forms and API

### Email
- **Nodemailer:** SMTP email sending capability

### File Handling
- **Multer:** File upload middleware
- **XLSX:** Spreadsheet parsing/generation

### Real-time Communication
- **ws:** WebSocket support for live updates

### Development Tools
- **Replit Plugins:** Runtime error overlay, cartographer, dev banner
- **TypeScript:** Strict mode enabled for type safety
- **ESLint/Prettier:** Code quality (configs in repo root)

### Database & ORM
- **Drizzle Kit:** Migration management
- **Drizzle Zod:** Schema to validation bridge
- **PostgreSQL:** Neon serverless driver

### Utility Libraries
- **date-fns:** Date manipulation
- **nanoid:** ID generation
- **uuid:** UUID generation
- **clsx + tailwind-merge:** Conditional class merging
- **class-variance-authority:** Component variant management

### Notable Architectural Decisions

**Monorepo without Workspace Manager:**
- No Turborepo/Nx/Lerna - simple folder structure
- Landing page is separate deployable unit
- Shared configs at root level

**Client Routing:**
- Main app uses wouter (lightweight, 1.2KB)
- Landing uses Next.js file-based routing
- Not using React Router despite common patterns

**Build Optimization:**
- Server dependencies selectively bundled (allowlist)
- Reduces node_modules scanning at runtime
- Faster cold starts in serverless environments

**Migration from React+Vite to Next.js:**
- Landing page migrated from `client/src/pages/landing/` to `apps/landing/`
- Migration manifest tracked in `.migration-manifest.json`
- Original components kept as examples in `client/src/components/landing/`