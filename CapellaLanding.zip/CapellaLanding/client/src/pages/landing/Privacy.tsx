import LegalPageLayout from "@/components/landing/LegalPageLayout";

export default function Privacy() {
  return (
    <LegalPageLayout title="Privacy Policy" lastUpdated="November 27, 2025">
      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Introduction</h2>
        <p className="text-muted-foreground leading-relaxed">
          Capella Pro ("we", "us", or "our") operates the Capella Pro AI Productivity Suite. 
          This Privacy Policy explains how we collect, use, and protect your personal information 
          when you use our services.
        </p>
      </section>

      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Information We Collect</h2>
        <p className="text-muted-foreground leading-relaxed mb-4">
          We collect the following types of information:
        </p>
        <ul className="list-disc pl-6 space-y-2 text-muted-foreground">
          <li>
            <strong className="text-foreground">Personal Information:</strong> Name, email address, 
            payment details, and account credentials when you register or make purchases.
          </li>
          <li>
            <strong className="text-foreground">Usage Data:</strong> Information about how you interact 
            with our features, including task management data, calendar entries, notes, and financial records.
          </li>
          <li>
            <strong className="text-foreground">Technical Data:</strong> IP address, browser type, 
            device information, and cookies to improve your experience.
          </li>
        </ul>
      </section>

      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-4">How We Use Your Information</h2>
        <p className="text-muted-foreground leading-relaxed mb-4">
          We use your information for the following purposes:
        </p>
        <ul className="list-disc pl-6 space-y-2 text-muted-foreground">
          <li>To provide and maintain the Capella Pro services</li>
          <li>To process payments securely via Razorpay</li>
          <li>To send you updates, newsletters, and marketing communications (with your consent)</li>
          <li>To improve our platform based on usage patterns and feedback</li>
          <li>To provide customer support and respond to inquiries</li>
        </ul>
      </section>

      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Data Security</h2>
        <p className="text-muted-foreground leading-relaxed">
          We take the security of your data seriously and implement:
        </p>
        <ul className="list-disc pl-6 space-y-2 text-muted-foreground mt-4">
          <li>Industry-standard encryption (SSL/TLS) for data in transit</li>
          <li>Secure payment processing through Razorpay's PCI-DSS compliant infrastructure</li>
          <li>Regular security audits and vulnerability assessments</li>
          <li>Access controls and authentication measures</li>
        </ul>
      </section>

      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Third-Party Services</h2>
        <p className="text-muted-foreground leading-relaxed">
          We use Razorpay for payment processing. When you make a payment, your payment information 
          is processed directly by Razorpay according to their{" "}
          <a href="https://razorpay.com/privacy/" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">
            Privacy Policy
          </a>. We do not store your complete credit card information on our servers.
        </p>
      </section>

      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Your Rights</h2>
        <p className="text-muted-foreground leading-relaxed mb-4">
          You have the following rights regarding your personal data:
        </p>
        <ul className="list-disc pl-6 space-y-2 text-muted-foreground">
          <li>Access and receive a copy of your personal data</li>
          <li>Correct inaccurate or incomplete information</li>
          <li>Request deletion of your personal data</li>
          <li>Opt-out of marketing communications at any time</li>
          <li>Export your data in a portable format</li>
        </ul>
      </section>

      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Contact Us</h2>
        <p className="text-muted-foreground leading-relaxed">
          If you have any questions about this Privacy Policy, please contact us at:{" "}
          <a href="mailto:support@capellapro.com" className="text-primary hover:underline">
            support@capellapro.com
          </a>
        </p>
      </section>
    </LegalPageLayout>
  );
}
