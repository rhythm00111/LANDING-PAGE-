import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Shield, CheckCircle } from "lucide-react";
import logoImg from "@assets/Screenshot 2025-07-18 133457_1764269643707.png";

export default function Verification() {
  return (
    <div className="py-16 sm:py-24">
      <div className="mx-auto max-w-2xl px-4 sm:px-6 lg:px-8">
        <Card className="overflow-hidden">
          <div className="bg-gradient-to-r from-primary to-chart-2 p-6 text-center">
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-white/20 backdrop-blur">
              <img src={logoImg} alt="Capella Pro Logo" className="h-10 w-10" />
            </div>
            <h1 className="mt-4 text-2xl font-bold text-white sm:text-3xl" data-testid="text-verification-title">
              Razorpay Merchant Verification
            </h1>
          </div>
          
          <CardContent className="p-6 sm:p-8">
            <div className="mb-6 flex items-center gap-2">
              <Shield className="h-5 w-5 text-primary" />
              <Badge variant="secondary">Official Verification Page</Badge>
            </div>
            
            <p className="text-muted-foreground leading-relaxed" data-testid="text-verification-description">
              This page confirms Capella Pro's identity for payment gateway onboarding with Razorpay. 
              This verification ensures secure and compliant payment processing for our users.
            </p>
            
            <div className="mt-8 rounded-lg bg-muted/50 p-6">
              <h2 className="mb-4 text-lg font-semibold">Business Details</h2>
              
              <dl className="space-y-4">
                <div className="flex items-start gap-3">
                  <CheckCircle className="mt-0.5 h-5 w-5 shrink-0 text-primary" />
                  <div>
                    <dt className="text-sm font-medium text-muted-foreground">Company Name</dt>
                    <dd className="text-foreground" data-testid="text-company-name">Capella Pro</dd>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <CheckCircle className="mt-0.5 h-5 w-5 shrink-0 text-primary" />
                  <div>
                    <dt className="text-sm font-medium text-muted-foreground">Service Type</dt>
                    <dd className="text-foreground" data-testid="text-service-type">AI Productivity Suite</dd>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <CheckCircle className="mt-0.5 h-5 w-5 shrink-0 text-primary" />
                  <div>
                    <dt className="text-sm font-medium text-muted-foreground">Business Category</dt>
                    <dd className="text-foreground" data-testid="text-business-category">
                      Software as a Service (SaaS)
                    </dd>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <CheckCircle className="mt-0.5 h-5 w-5 shrink-0 text-primary" />
                  <div>
                    <dt className="text-sm font-medium text-muted-foreground">Website</dt>
                    <dd className="text-foreground" data-testid="text-website">
                      <a href="/" className="text-primary hover:underline">
                        www.capellapro.com
                      </a>
                    </dd>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <CheckCircle className="mt-0.5 h-5 w-5 shrink-0 text-primary" />
                  <div>
                    <dt className="text-sm font-medium text-muted-foreground">Verification Contact</dt>
                    <dd className="text-foreground" data-testid="text-verification-email">
                      <a href="mailto:verify@capellapro.com" className="text-primary hover:underline">
                        verify@capellapro.com
                      </a>
                    </dd>
                  </div>
                </div>
              </dl>
            </div>
            
            <p className="mt-6 text-center text-sm text-muted-foreground">
              For any verification inquiries, please contact{" "}
              <a href="mailto:verify@capellapro.com" className="text-primary hover:underline">
                verify@capellapro.com
              </a>
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
