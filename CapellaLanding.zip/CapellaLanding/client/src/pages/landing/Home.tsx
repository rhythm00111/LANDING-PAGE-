import Hero from "@/components/landing/Hero";
import Features from "@/components/landing/Features";
import Pricing from "@/components/landing/Pricing";
import CTASection from "@/components/landing/CTASection";

export default function Home() {
  return (
    <main>
      <Hero />
      <Features />
      <Pricing />
      <CTASection />
    </main>
  );
}
