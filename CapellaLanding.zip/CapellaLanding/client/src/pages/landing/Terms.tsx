import LegalPageLayout from "@/components/landing/LegalPageLayout";

export default function Terms() {
  return (
    <LegalPageLayout title="Terms of Service" lastUpdated="November 27, 2025">
      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Acceptance of Terms</h2>
        <p className="text-muted-foreground leading-relaxed">
          By accessing or using Capella Pro, you agree to be bound by these Terms of Service. 
          If you do not agree to these terms, please do not use our services. These terms apply 
          to all visitors, users, and others who access or use Capella Pro.
        </p>
      </section>

      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Service Description</h2>
        <p className="text-muted-foreground leading-relaxed">
          Capella Pro is an AI-powered productivity suite that provides the following core features:
        </p>
        <ul className="list-disc pl-6 space-y-2 text-muted-foreground mt-4">
          <li>AI Dashboard for centralized productivity insights</li>
          <li>AI Task Management for smart task organization</li>
          <li>AI Calendar for intelligent scheduling</li>
          <li>AI Finance for expense tracking and insights</li>
          <li>AI Notes for smart note-taking</li>
          <li>CRM for customer relationship management</li>
          <li>AI Templates for pre-built workflows</li>
          <li>Whiteboard for visual collaboration</li>
          <li>Focus Mode for distraction-free work</li>
        </ul>
      </section>

      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-4">User Accounts</h2>
        <p className="text-muted-foreground leading-relaxed mb-4">
          To use Capella Pro, you must:
        </p>
        <ul className="list-disc pl-6 space-y-2 text-muted-foreground">
          <li>Be at least 18 years of age or have parental consent</li>
          <li>Provide accurate and complete registration information</li>
          <li>Maintain the security of your password and account</li>
          <li>Notify us immediately of any unauthorized use</li>
          <li>Accept responsibility for all activities under your account</li>
        </ul>
      </section>

      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Subscription and Payments</h2>
        <p className="text-muted-foreground leading-relaxed mb-4">
          Our subscription terms include:
        </p>
        <ul className="list-disc pl-6 space-y-2 text-muted-foreground">
          <li>Monthly and annual billing options are available</li>
          <li>All payments are processed securely via Razorpay</li>
          <li>Subscriptions auto-renew unless cancelled before the renewal date</li>
          <li>Prices are subject to change with 30 days notice</li>
          <li>Refunds are subject to our Refund Policy</li>
        </ul>
      </section>

      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Acceptable Use</h2>
        <p className="text-muted-foreground leading-relaxed mb-4">
          You agree not to use Capella Pro for:
        </p>
        <ul className="list-disc pl-6 space-y-2 text-muted-foreground">
          <li>Any illegal or unauthorized purpose</li>
          <li>Attempting to gain unauthorized access to our systems</li>
          <li>Transmitting spam, malware, or harmful content</li>
          <li>Violating any applicable laws or regulations</li>
          <li>Infringing on the intellectual property rights of others</li>
        </ul>
      </section>

      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Intellectual Property</h2>
        <p className="text-muted-foreground leading-relaxed">
          All content, features, and functionality of Capella Pro are owned by Capella Pro and 
          are protected by international copyright, trademark, and other intellectual property laws. 
          You are granted a limited, non-exclusive, non-transferable license to use the service 
          for personal or business purposes in accordance with these terms.
        </p>
      </section>

      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Limitation of Liability</h2>
        <p className="text-muted-foreground leading-relaxed">
          Capella Pro is provided "as is" without warranties of any kind. We do not guarantee 
          that the service will be uninterrupted, secure, or error-free. In no event shall 
          Capella Pro be liable for any indirect, incidental, special, or consequential damages 
          arising out of your use of the service.
        </p>
      </section>

      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Termination</h2>
        <p className="text-muted-foreground leading-relaxed">
          We reserve the right to suspend or terminate your account at any time for violations 
          of these terms or for any other reason at our sole discretion. Upon termination, 
          your right to use the service will immediately cease.
        </p>
      </section>

      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Changes to Terms</h2>
        <p className="text-muted-foreground leading-relaxed">
          We may update these Terms of Service from time to time. We will notify you of any 
          changes by posting the new terms on this page and updating the "Last Updated" date. 
          Your continued use of the service after such changes constitutes acceptance of the new terms.
        </p>
      </section>

      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Governing Law</h2>
        <p className="text-muted-foreground leading-relaxed">
          These Terms of Service shall be governed by and construed in accordance with the laws 
          of India. Any disputes arising from these terms shall be subject to the exclusive 
          jurisdiction of the courts in India.
        </p>
      </section>

      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Contact Us</h2>
        <p className="text-muted-foreground leading-relaxed">
          If you have any questions about these Terms of Service, please contact us at:{" "}
          <a href="mailto:legal@capellapro.com" className="text-primary hover:underline">
            legal@capellapro.com
          </a>
        </p>
      </section>
    </LegalPageLayout>
  );
}
