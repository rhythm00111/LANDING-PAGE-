import LegalPageLayout from "@/components/landing/LegalPageLayout";

export default function Cookies() {
  return (
    <LegalPageLayout title="Cookie Policy" lastUpdated="November 27, 2025">
      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-4">What Are Cookies</h2>
        <p className="text-muted-foreground leading-relaxed">
          Cookies are small text files that are stored on your device (computer, tablet, or mobile) 
          when you visit websites. They help websites remember your preferences, understand how you 
          use the site, and improve your overall experience.
        </p>
      </section>

      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Types of Cookies We Use</h2>
        <p className="text-muted-foreground leading-relaxed mb-4">
          Capella Pro uses the following types of cookies:
        </p>
        
        <div className="space-y-4">
          <div className="border-l-2 border-primary pl-4">
            <h3 className="font-medium text-foreground">Essential Cookies</h3>
            <p className="text-sm text-muted-foreground mt-1">
              Required for basic website functionality, including authentication, session management, 
              and security features. These cannot be disabled.
            </p>
          </div>
          
          <div className="border-l-2 border-primary pl-4">
            <h3 className="font-medium text-foreground">Functional Cookies</h3>
            <p className="text-sm text-muted-foreground mt-1">
              Remember your preferences like language settings, theme choices, and customization options 
              to provide a personalized experience.
            </p>
          </div>
          
          <div className="border-l-2 border-primary pl-4">
            <h3 className="font-medium text-foreground">Analytics Cookies</h3>
            <p className="text-sm text-muted-foreground mt-1">
              Help us understand how visitors interact with our website by collecting information 
              about page visits, time spent, and navigation patterns.
            </p>
          </div>
          
          <div className="border-l-2 border-primary pl-4">
            <h3 className="font-medium text-foreground">Marketing Cookies</h3>
            <p className="text-sm text-muted-foreground mt-1">
              Used to track visitors across websites to display relevant advertisements and measure 
              the effectiveness of our marketing campaigns.
            </p>
          </div>
        </div>
      </section>

      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Third-Party Cookies</h2>
        <p className="text-muted-foreground leading-relaxed mb-4">
          We use the following third-party services that may set cookies:
        </p>
        <ul className="list-disc pl-6 space-y-2 text-muted-foreground">
          <li>
            <strong className="text-foreground">Google Analytics:</strong> Used to analyze website 
            traffic and user behavior. You can opt-out using the{" "}
            <a 
              href="https://tools.google.com/dlpage/gaoptout" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-primary hover:underline"
            >
              Google Analytics Opt-out Browser Add-on
            </a>
          </li>
          <li>
            <strong className="text-foreground">Razorpay:</strong> Our payment processor may set 
            cookies for fraud prevention and secure payment processing
          </li>
        </ul>
      </section>

      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Managing Cookies</h2>
        <p className="text-muted-foreground leading-relaxed mb-4">
          You can control and manage cookies in several ways:
        </p>
        <ul className="list-disc pl-6 space-y-2 text-muted-foreground">
          <li>
            <strong className="text-foreground">Browser Settings:</strong> Most browsers allow you 
            to view, delete, and block cookies through settings. Check your browser's help section 
            for instructions.
          </li>
          <li>
            <strong className="text-foreground">Opt-Out Links:</strong> Use the opt-out links 
            provided by third-party services like Google Analytics.
          </li>
          <li>
            <strong className="text-foreground">Device Settings:</strong> Mobile devices typically 
            provide settings to limit ad tracking and manage cookies.
          </li>
        </ul>
        <p className="text-muted-foreground leading-relaxed mt-4">
          Note: Disabling certain cookies may affect the functionality of Capella Pro and limit 
          your ability to use some features.
        </p>
      </section>

      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Cookie Duration</h2>
        <p className="text-muted-foreground leading-relaxed">
          <strong className="text-foreground">Session Cookies:</strong> Temporary cookies that expire 
          when you close your browser.<br /><br />
          <strong className="text-foreground">Persistent Cookies:</strong> Remain on your device for 
          a set period (typically 30 days to 2 years) or until you delete them.
        </p>
      </section>

      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Updates to This Policy</h2>
        <p className="text-muted-foreground leading-relaxed">
          We may update this Cookie Policy from time to time to reflect changes in technology, 
          legislation, or our data practices. Any changes will be posted on this page with an 
          updated revision date.
        </p>
      </section>

      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Contact Us</h2>
        <p className="text-muted-foreground leading-relaxed">
          If you have any questions about our use of cookies, please contact us at:{" "}
          <a href="mailto:privacy@capellapro.com" className="text-primary hover:underline">
            privacy@capellapro.com
          </a>
        </p>
      </section>
    </LegalPageLayout>
  );
}
