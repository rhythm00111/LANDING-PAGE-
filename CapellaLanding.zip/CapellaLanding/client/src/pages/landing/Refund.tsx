import LegalPageLayout from "@/components/landing/LegalPageLayout";

export default function Refund() {
  return (
    <LegalPageLayout title="Refund Policy" lastUpdated="November 27, 2025">
      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-4">7-Day Money-Back Guarantee</h2>
        <p className="text-muted-foreground leading-relaxed">
          We offer a full refund within 7 days of your initial purchase. If you're not satisfied 
          with Capella Pro for any reason, simply contact us within 7 days of your purchase date 
          to receive a complete refund, no questions asked.
        </p>
      </section>

      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Eligibility for Refund</h2>
        <p className="text-muted-foreground leading-relaxed mb-4">
          To be eligible for a refund, you must meet the following criteria:
        </p>
        <ul className="list-disc pl-6 space-y-2 text-muted-foreground">
          <li>You are a first-time subscriber to Capella Pro</li>
          <li>The refund request is made within 7 days of the initial purchase</li>
          <li>Your account has not been previously refunded</li>
          <li>You provide a valid reason for the refund request</li>
        </ul>
      </section>

      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Refund Process</h2>
        <p className="text-muted-foreground leading-relaxed mb-4">
          To request a refund, please follow these steps:
        </p>
        <ol className="list-decimal pl-6 space-y-2 text-muted-foreground">
          <li>
            Send an email to{" "}
            <a href="mailto:support@capellapro.com" className="text-primary hover:underline">
              support@capellapro.com
            </a>
          </li>
          <li>Include your order number and registered email address</li>
          <li>Provide a brief explanation of why you're requesting a refund</li>
          <li>Our team will review your request within 2-3 business days</li>
        </ol>
      </section>

      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Processing Time</h2>
        <p className="text-muted-foreground leading-relaxed">
          Once your refund is approved, please allow 7-10 business days for the refund to be 
          processed and reflected in your original payment method. The exact timing may vary 
          depending on your bank or payment provider.
        </p>
      </section>

      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Non-Refundable Items</h2>
        <p className="text-muted-foreground leading-relaxed mb-4">
          The following are not eligible for refunds:
        </p>
        <ul className="list-disc pl-6 space-y-2 text-muted-foreground">
          <li>Subscription payments made after the 7-day guarantee period</li>
          <li>Annual plans after 30 days from the date of purchase</li>
          <li>Enterprise contracts with custom terms</li>
          <li>Accounts that have violated our Terms of Service</li>
          <li>Previously refunded accounts</li>
        </ul>
      </section>

      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Cancellation vs. Refund</h2>
        <p className="text-muted-foreground leading-relaxed">
          Please note that cancelling your subscription is different from requesting a refund. 
          Cancellation stops future billing but does not refund previous payments. If you wish 
          to cancel your subscription, you can do so from your account settings at any time.
        </p>
      </section>

      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Contact Us</h2>
        <p className="text-muted-foreground leading-relaxed">
          For refund inquiries, please contact our support team at:{" "}
          <a href="mailto:refunds@capellapro.com" className="text-primary hover:underline">
            refunds@capellapro.com
          </a>
        </p>
      </section>
    </LegalPageLayout>
  );
}
