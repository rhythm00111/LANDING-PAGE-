import CTASection from "../landing/CTASection";

export default function CTASectionExample() {
  return <CTASection />;
}
