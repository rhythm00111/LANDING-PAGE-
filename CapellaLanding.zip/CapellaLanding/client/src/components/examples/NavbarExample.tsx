import Navbar from "../landing/Navbar";

export default function NavbarExample() {
  return <Navbar />;
}
