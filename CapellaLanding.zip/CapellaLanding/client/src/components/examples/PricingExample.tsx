import Pricing from "../landing/Pricing";

export default function PricingExample() {
  return <Pricing />;
}
