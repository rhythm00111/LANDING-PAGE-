import Hero from "../landing/Hero";

export default function HeroExample() {
  return <Hero />;
}
