import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Users } from "lucide-react";
import { Link } from "wouter";

export default function Hero() {
  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-primary/5 via-background to-chart-2/5">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_80%_50%_at_50%_-20%,rgba(120,119,198,0.15),transparent)]" />
      
      <div className="relative mx-auto max-w-7xl px-4 py-24 sm:px-6 sm:py-32 lg:px-8 lg:py-40">
        <div className="mx-auto max-w-3xl text-center">
          <Badge variant="secondary" className="mb-6" data-testid="badge-tagline">
            AI Productivity Suite
          </Badge>
          
          <h1 className="text-4xl font-bold tracking-tight sm:text-5xl lg:text-6xl" data-testid="text-hero-title">
            Transform Your Productivity{" "}
            <span className="bg-gradient-to-r from-primary to-chart-2 bg-clip-text text-transparent">
              with AI
            </span>
          </h1>
          
          <p className="mt-6 text-lg leading-relaxed text-muted-foreground sm:text-xl" data-testid="text-hero-description">
            The all-in-one AI-powered workspace that helps you manage tasks, 
            schedule meetings, track finances, and collaborate seamlessly. 
            Work smarter, not harder.
          </p>
          
          <div className="mt-10 flex flex-col items-center justify-center gap-4 sm:flex-row">
            <Button size="lg" className="w-full sm:w-auto" data-testid="button-hero-getstarted">
              Get Started Free
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
            <Link href="#pricing">
              <Button variant="outline" size="lg" className="w-full sm:w-auto" data-testid="button-hero-pricing">
                View Pricing
              </Button>
            </Link>
          </div>
          
          <div className="mt-10 flex items-center justify-center gap-2 text-sm text-muted-foreground" data-testid="text-trust-badge">
            <Users className="h-4 w-4" />
            <span>Trusted by 10,000+ professionals worldwide</span>
          </div>
        </div>
      </div>
    </section>
  );
}
