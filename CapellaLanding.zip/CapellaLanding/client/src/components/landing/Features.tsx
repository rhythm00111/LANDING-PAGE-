import { Card, CardContent } from "@/components/ui/card";
import {
  LayoutDashboard,
  CheckSquare,
  Calendar,
  Wallet,
  FileText,
  Users,
  FileCode,
  PenTool,
  Focus,
} from "lucide-react";

const features = [
  {
    icon: LayoutDashboard,
    title: "AI Dashboard",
    description: "Central hub for all your productivity insights and analytics powered by AI.",
  },
  {
    icon: CheckSquare,
    title: "AI Task Management",
    description: "Smart task organization with AI-driven prioritization and automation.",
  },
  {
    icon: Calendar,
    title: "AI Calendar",
    description: "Intelligent scheduling that learns your preferences and optimizes your time.",
  },
  {
    icon: Wallet,
    title: "AI Finance",
    description: "Expense tracking and financial insights with AI-powered categorization.",
  },
  {
    icon: FileText,
    title: "AI Notes",
    description: "Smart note-taking with AI summarization and organization features.",
  },
  {
    icon: Users,
    title: "CRM",
    description: "Customer relationship management to track leads and grow your business.",
  },
  {
    icon: FileCode,
    title: "AI Templates",
    description: "Pre-built workflows and templates to accelerate your productivity.",
  },
  {
    icon: PenTool,
    title: "Whiteboard",
    description: "Visual collaboration space for brainstorming and planning projects.",
  },
  {
    icon: Focus,
    title: "Focus Mode",
    description: "Distraction-free environment to maximize your deep work sessions.",
  },
];

export default function Features() {
  return (
    <section className="py-20 sm:py-28" id="features">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl" data-testid="text-features-title">
            Everything You Need to Succeed
          </h2>
          <p className="mt-4 text-lg text-muted-foreground" data-testid="text-features-description">
            Nine powerful AI-driven tools designed to streamline your workflow and boost productivity.
          </p>
        </div>

        <div className="mt-16 grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {features.map((feature, index) => (
            <Card
              key={feature.title}
              className="hover-elevate transition-all duration-200"
              data-testid={`card-feature-${index}`}
            >
              <CardContent className="p-6">
                <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                  <feature.icon className="h-6 w-6 text-primary" />
                </div>
                <h3 className="mt-4 text-lg font-semibold" data-testid={`text-feature-title-${index}`}>
                  {feature.title}
                </h3>
                <p className="mt-2 text-sm text-muted-foreground" data-testid={`text-feature-desc-${index}`}>
                  {feature.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
