import { ReactNode } from "react";

interface LegalPageLayoutProps {
  title: string;
  lastUpdated: string;
  children: ReactNode;
}

export default function LegalPageLayout({ title, lastUpdated, children }: LegalPageLayoutProps) {
  return (
    <div className="py-12 sm:py-16">
      <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
        <div className="mb-8 border-b pb-8">
          <h1 className="text-3xl font-bold tracking-tight sm:text-4xl" data-testid="text-legal-title">
            {title}
          </h1>
          <p className="mt-2 text-sm text-muted-foreground" data-testid="text-legal-updated">
            Last Updated: {lastUpdated}
          </p>
        </div>
        <div className="prose prose-gray max-w-none dark:prose-invert" data-testid="content-legal">
          {children}
        </div>
      </div>
    </div>
  );
}
