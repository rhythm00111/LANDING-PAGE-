# Capella Pro Landing Page - Design Guidelines

## Design Approach
**Reference-Based Approach**: Drawing inspiration from Linear, Notion, and Superhuman's modern SaaS aesthetic with clean minimalism, purposeful animations, and professional polish.

## Core Design Principles
- **Clarity First**: Every element serves a purpose - no decorative bloat
- **Professional SaaS**: Enterprise-grade feel with consumer-friendly approachability  
- **AI-Forward**: Design language that communicates intelligence and automation
- **Trust & Credibility**: Legal pages and verification establish legitimacy for Razorpay onboarding

## Typography
- **Headings**: Font-sans, bold weights (600-700)
  - H1: Large, impactful (48-72px desktop, 32-40px mobile)
  - H2: Section headers (36-48px desktop, 28-32px mobile)
  - H3: Feature titles (24-28px)
- **Body**: Font-sans, regular weight (16-18px), line-height 1.6 for readability
- **Legal Pages**: Slightly smaller body text (15-16px), tighter line-height 1.5

## Layout & Spacing System
**Tailwind Units**: Standardize on 4, 8, 12, 16, 20, 24, 32 for consistent rhythm
- Section padding: py-20 to py-32 (desktop), py-12 to py-16 (mobile)
- Component gaps: gap-8 to gap-12 for grids
- Container max-width: max-w-7xl for full sections, max-w-4xl for text-heavy legal pages

## Homepage Structure

### 1. Hero Section (80vh)
- **Image**: Full-width background gradient (blue to purple fade) OR abstract AI-themed illustration showing connected nodes/productivity elements
- **Layout**: Centered content with generous whitespace
- **Elements**: 
  - Large headline with gradient text effect
  - 2-line subheading explaining AI productivity suite
  - Two CTAs side-by-side: "Get Started" (primary, blurred background button) + "View Pricing" (secondary)
  - Trust badge below CTAs: "Trusted by 10,000+ professionals"

### 2. Features Section
- **Layout**: 3-column grid (desktop), 2-column (tablet), 1-column (mobile)
- **Cards**: Subtle border, hover lift effect, white background
- **Structure per card**: Icon (top), feature name, 1-line description
- **Icons**: Use Heroicons, consistent size (w-8 h-8), primary color fill
- **Spacing**: gap-8 between cards, p-8 internal padding

### 3. Pricing Section
- **Layout**: 3-column cards, center card (Pro) elevated and highlighted
- **Visual Hierarchy**: Pro tier has subtle shadow and border accent
- **Elements per tier**: 
  - Plan name, price (large), billing period
  - Feature list with checkmarks
  - CTA button (primary for Pro, secondary for others)
- **Spacing**: gap-8 between cards

### 4. Final CTA Section
- **Layout**: Centered, contained width (max-w-3xl)
- **Elements**: Bold headline, supporting text, single primary CTA
- **Background**: Subtle gradient or solid with ample padding (py-24)

## Navigation Bar
- **Layout**: Horizontal, full-width, sticky on scroll
- **Structure**: Logo (left) | Legal links (center) | Sign In + Get Started (right)
- **Styling**: Clean white background, subtle bottom border, backdrop blur on scroll
- **Links**: Inline, adequate spacing (px-4), hover underline effect
- **CTAs**: "Sign In" (text link), "Get Started" (button, primary color)

## Footer
- **Layout**: Multi-column (4 columns desktop, stack on mobile)
- **Columns**: 
  1. Company info + logo
  2. Product features (condensed list)
  3. Legal links (Privacy, Terms, Refund, Cookies)
  4. Contact information + social media placeholders
- **Styling**: Dark background (gray-900), light text, py-16 padding
- **Bottom bar**: Copyright, additional links

## Legal Pages (Privacy, Terms, Refund, Cookies)
- **Layout**: Single column, centered (max-w-4xl)
- **Structure**: 
  - Page title (H1)
  - Last updated date (subtle gray)
  - Table of contents (linked sections)
  - Content sections with H2 headings
- **Typography**: Professional, scannable, adequate line-height
- **Spacing**: py-12 section padding, mb-8 between sections
- **Lists**: Proper bullets/numbers, indentation, spacing

## Verification Page
- **Layout**: Centered card (max-w-2xl)
- **Elements**: 
  - Logo at top
  - H1: "Razorpay Merchant Verification"
  - Clean paragraph explaining purpose
  - Business details in definition list format
  - Professional contact email
- **Styling**: Minimal, trustworthy, ample whitespace

## Component Library

### Buttons
- **Primary**: Blue/purple gradient background, white text, rounded-lg, px-8 py-3
- **Secondary**: Border style, transparent background, primary color text
- **Hover**: Subtle scale (1.02) and shadow increase

### Cards
- **Standard**: White background, rounded-xl, border, p-8
- **Hover**: Lift effect (translateY(-4px)), increased shadow

### Input Fields (if needed for CTAs)
- **Style**: Border, rounded-lg, px-4 py-3, focus ring effect
- **Labels**: Above input, font-medium, mb-2

## Images Strategy
- **Hero**: Use gradient background OR abstract productivity illustration (nodes, connections, dashboards) - NOT product screenshots
- **Features**: Icon-based, no feature screenshots
- **No other images needed**: Keep focus on clean, professional design

## Animations (Minimal)
- Subtle fade-in on scroll for feature cards
- Smooth hover transitions (200-300ms)
- NO complex animations, NO parallax, NO scroll-jacking

## Responsive Breakpoints
- Mobile: < 768px (stack everything, full-width buttons)
- Tablet: 768px - 1024px (2-column grids)
- Desktop: > 1024px (3-column grids, full layout)

## Accessibility
- Semantic HTML throughout
- Proper heading hierarchy (no skipped levels)
- ARIA labels for icon-only buttons
- Keyboard navigation support
- Sufficient color contrast (WCAG AA minimum)

This design delivers a polished, professional SaaS landing page that establishes credibility while showcasing Capella Pro's AI productivity features with clarity and sophistication.