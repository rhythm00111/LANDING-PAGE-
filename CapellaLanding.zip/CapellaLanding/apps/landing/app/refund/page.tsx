import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Refund Policy — Capella Pro",
  description: "Refund policy and money-back guarantee for Capella Pro subscriptions.",
};

export default function RefundPage() {
  return (
    <div className="py-12 sm:py-16">
      <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
        <div className="mb-8 border-b border-gray-200 pb-8">
          <h1 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">
            Refund Policy
          </h1>
          <p className="mt-2 text-sm text-gray-500">
            Last Updated: November 27, 2025
          </p>
        </div>

        <div className="prose prose-gray max-w-none">
          <section className="mb-8">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">7-Day Money-Back Guarantee</h2>
            <p className="text-gray-600 leading-relaxed">
              We offer a full refund within 7 days of your initial purchase. If you're not satisfied 
              with Capella Pro for any reason, simply contact us within 7 days of your purchase date 
              to receive a complete refund, no questions asked.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Refund Windows</h2>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200 mt-4">
                <thead>
                  <tr>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900 bg-gray-50">Plan Type</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900 bg-gray-50">Refund Window</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900 bg-gray-50">Conditions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  <tr>
                    <td className="px-4 py-3 text-sm text-gray-600">Monthly Pro</td>
                    <td className="px-4 py-3 text-sm text-gray-600">7 days</td>
                    <td className="px-4 py-3 text-sm text-gray-600">First-time subscribers only</td>
                  </tr>
                  <tr>
                    <td className="px-4 py-3 text-sm text-gray-600">Annual Pro</td>
                    <td className="px-4 py-3 text-sm text-gray-600">30 days</td>
                    <td className="px-4 py-3 text-sm text-gray-600">First-time subscribers only</td>
                  </tr>
                  <tr>
                    <td className="px-4 py-3 text-sm text-gray-600">Enterprise</td>
                    <td className="px-4 py-3 text-sm text-gray-600">As per contract</td>
                    <td className="px-4 py-3 text-sm text-gray-600">Custom terms apply</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </section>

          <section className="mb-8">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Eligibility for Refund</h2>
            <p className="text-gray-600 leading-relaxed mb-4">
              To be eligible for a refund, you must meet the following criteria:
            </p>
            <ul className="list-disc pl-6 space-y-2 text-gray-600">
              <li>You are a first-time subscriber to Capella Pro</li>
              <li>The refund request is made within the applicable refund window</li>
              <li>Your account has not been previously refunded</li>
              <li>You provide a valid reason for the refund request</li>
              <li>Your account has not violated our Terms of Service</li>
            </ul>
          </section>

          <section className="mb-8">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Refund Process</h2>
            <p className="text-gray-600 leading-relaxed mb-4">
              To request a refund, please follow these steps:
            </p>
            <ol className="list-decimal pl-6 space-y-2 text-gray-600">
              <li>
                Send an email to{" "}
                <a href="mailto:support@capellapro.co" className="text-indigo-600 hover:underline">
                  support@capellapro.co
                </a>
              </li>
              <li>Include your order number and registered email address</li>
              <li>Provide a brief explanation of why you're requesting a refund</li>
              <li>Our team will review your request within 2-3 business days</li>
              <li>You will receive confirmation once your refund is approved</li>
            </ol>
          </section>

          <section className="mb-8">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Processing Time</h2>
            <p className="text-gray-600 leading-relaxed">
              Once your refund is approved, please allow 7-10 business days for the refund to be 
              processed and reflected in your original payment method. The exact timing may vary 
              depending on your bank or payment provider.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Razorpay Refund Note</h2>
            <p className="text-gray-600 leading-relaxed">
              All refunds are processed through Razorpay, our payment processor. The refund will be 
              credited to the same payment method used for the original transaction. International 
              transactions may take additional time due to banking procedures. Currency conversion 
              rates at the time of refund may differ from the original purchase.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Non-Refundable Items</h2>
            <p className="text-gray-600 leading-relaxed mb-4">
              The following are not eligible for refunds:
            </p>
            <ul className="list-disc pl-6 space-y-2 text-gray-600">
              <li>Subscription payments made after the applicable refund window</li>
              <li>Renewal payments (only first subscription is eligible)</li>
              <li>Enterprise contracts with custom terms</li>
              <li>Accounts that have violated our Terms of Service</li>
              <li>Previously refunded accounts</li>
              <li>Promotional or discounted subscriptions (unless specified)</li>
            </ul>
          </section>

          <section className="mb-8">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Cancellation vs. Refund</h2>
            <p className="text-gray-600 leading-relaxed">
              Please note that cancelling your subscription is different from requesting a refund. 
              Cancellation stops future billing but does not refund previous payments. If you wish 
              to cancel your subscription, you can do so from your account settings at any time. 
              Your access will continue until the end of your current billing period.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Contact Us</h2>
            <p className="text-gray-600 leading-relaxed">
              For refund inquiries, please contact our support team at:{" "}
              <a href="mailto:refunds@capellapro.com" className="text-indigo-600 hover:underline">
                refunds@capellapro.com
              </a>
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}
