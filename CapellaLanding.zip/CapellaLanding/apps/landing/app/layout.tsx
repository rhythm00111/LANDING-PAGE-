import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "@/styles/globals.css";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "Capella Pro — AI Productivity Suite",
  description: "Transform your productivity with Capella Pro's AI-powered suite. Features AI Dashboard, Task Management, Calendar, Finance, Notes, CRM, Templates, Whiteboard, and Focus Mode.",
  openGraph: {
    title: "Capella Pro — AI Productivity Suite",
    description: "Transform your productivity with AI-powered tools. Dashboard, Tasks, Calendar, Finance, Notes, CRM, and more.",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <div className="flex min-h-screen flex-col">
          <Navbar />
          <main className="flex-1">{children}</main>
          <Footer />
        </div>
      </body>
    </html>
  );
}
