import type { Metadata } from "next";
import Image from "next/image";
import { Shield, CheckCircle, Building, Globe, Mail, CreditCard } from "lucide-react";

export const metadata: Metadata = {
  title: "Merchant Verification — Capella Pro",
  description: "Razorpay merchant verification and KYC information for Capella Pro.",
};

export default function VerificationPage() {
  return (
    <div className="py-16 sm:py-24">
      <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
        <div className="overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-sm">
          <div className="bg-gradient-to-r from-indigo-600 to-purple-600 p-8 text-center">
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-white/20 backdrop-blur">
              <Image
                src="/logo.png"
                alt="Capella Pro Logo"
                width={40}
                height={40}
                className="h-10 w-10"
              />
            </div>
            <h1 className="mt-4 text-2xl font-bold text-white sm:text-3xl">
              Razorpay Merchant Verification
            </h1>
            <p className="mt-2 text-white/80">
              Official verification page for payment gateway onboarding
            </p>
          </div>
          
          <div className="p-8">
            <div className="mb-6 flex items-center gap-2">
              <Shield className="h-5 w-5 text-indigo-600" />
              <span className="rounded-full bg-indigo-100 px-3 py-1 text-sm font-medium text-indigo-700">
                Official Verification Page
              </span>
            </div>
            
            <p className="text-gray-600 leading-relaxed">
              This page confirms Capella Pro's identity for payment gateway onboarding with Razorpay. 
              This verification ensures secure and compliant payment processing for our users across India.
            </p>
            
            <div className="mt-8 rounded-xl bg-gray-50 p-6">
              <h2 className="mb-6 text-lg font-semibold text-gray-900">Business Details</h2>
              
              <dl className="space-y-5">
                <div className="flex items-start gap-4">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-indigo-100">
                    <Building className="h-5 w-5 text-indigo-600" />
                  </div>
                  <div>
                    <dt className="text-sm font-medium text-gray-500">Company Name</dt>
                    <dd className="text-gray-900">Capella Pro Technologies Pvt. Ltd.</dd>
                  </div>
                </div>
                
                <div className="flex items-start gap-4">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-indigo-100">
                    <CheckCircle className="h-5 w-5 text-indigo-600" />
                  </div>
                  <div>
                    <dt className="text-sm font-medium text-gray-500">Service Type</dt>
                    <dd className="text-gray-900">AI Productivity Suite (SaaS)</dd>
                  </div>
                </div>
                
                <div className="flex items-start gap-4">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-indigo-100">
                    <CreditCard className="h-5 w-5 text-indigo-600" />
                  </div>
                  <div>
                    <dt className="text-sm font-medium text-gray-500">Business Category</dt>
                    <dd className="text-gray-900">Software as a Service (SaaS) / Technology</dd>
                  </div>
                </div>
                
                <div className="flex items-start gap-4">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-indigo-100">
                    <Globe className="h-5 w-5 text-indigo-600" />
                  </div>
                  <div>
                    <dt className="text-sm font-medium text-gray-500">Website</dt>
                    <dd className="text-gray-900">
                      <a href="/" className="text-indigo-600 hover:underline">
                        www.capellapro.com
                      </a>
                    </dd>
                  </div>
                </div>
                
                <div className="flex items-start gap-4">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-indigo-100">
                    <Mail className="h-5 w-5 text-indigo-600" />
                  </div>
                  <div>
                    <dt className="text-sm font-medium text-gray-500">Verification Contact</dt>
                    <dd className="text-gray-900">
                      <a href="mailto:verify@capellapro.com" className="text-indigo-600 hover:underline">
                        verify@capellapro.com
                      </a>
                    </dd>
                  </div>
                </div>
              </dl>
            </div>

            <div className="mt-8 rounded-xl border border-amber-200 bg-amber-50 p-6">
              <h3 className="font-semibold text-amber-800">KYC Information</h3>
              <p className="mt-2 text-sm text-amber-700">
                This business is registered in India and complies with all RBI guidelines for 
                digital payment processing. Our KYC documents have been submitted to Razorpay 
                for verification. For any verification queries, please contact our verification team.
              </p>
            </div>
            
            <div className="mt-8 border-t border-gray-200 pt-6">
              <h3 className="font-semibold text-gray-900">Products & Services Offered</h3>
              <ul className="mt-4 grid gap-2 sm:grid-cols-2">
                {[
                  "AI Dashboard",
                  "AI Task Management",
                  "AI Calendar",
                  "AI Notes",
                  "AI Finance",
                  "CRM",
                  "AI Templates",
                  "Whiteboard",
                  "Focus Mode",
                ].map((product) => (
                  <li key={product} className="flex items-center gap-2 text-sm text-gray-600">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    {product}
                  </li>
                ))}
              </ul>
            </div>
            
            <p className="mt-8 text-center text-sm text-gray-500">
              For any verification inquiries, please contact{" "}
              <a href="mailto:verify@capellapro.com" className="text-indigo-600 hover:underline">
                verify@capellapro.com
              </a>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
