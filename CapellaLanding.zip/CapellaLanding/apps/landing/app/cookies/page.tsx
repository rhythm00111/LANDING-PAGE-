import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Cookie Policy — Capella Pro",
  description: "Learn about how Capella Pro uses cookies and similar technologies.",
};

export default function CookiesPage() {
  return (
    <div className="py-12 sm:py-16">
      <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
        <div className="mb-8 border-b border-gray-200 pb-8">
          <h1 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">
            Cookie Policy
          </h1>
          <p className="mt-2 text-sm text-gray-500">
            Last Updated: November 27, 2025
          </p>
        </div>

        <div className="prose prose-gray max-w-none">
          <section className="mb-8">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">What Are Cookies</h2>
            <p className="text-gray-600 leading-relaxed">
              Cookies are small text files that are stored on your device (computer, tablet, or mobile) 
              when you visit websites. They help websites remember your preferences, understand how you 
              use the site, and improve your overall experience.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Types of Cookies We Use</h2>
            <p className="text-gray-600 leading-relaxed mb-4">
              Capella Pro uses the following types of cookies:
            </p>
            
            <div className="space-y-4">
              <div className="border-l-4 border-indigo-500 pl-4 py-2 bg-gray-50 rounded-r">
                <h3 className="font-semibold text-gray-900">Session Cookies</h3>
                <p className="text-sm text-gray-600 mt-1">
                  Temporary cookies that expire when you close your browser. Used for authentication 
                  and maintaining your session while you use Capella Pro.
                </p>
              </div>
              
              <div className="border-l-4 border-indigo-500 pl-4 py-2 bg-gray-50 rounded-r">
                <h3 className="font-semibold text-gray-900">Authentication Cookies</h3>
                <p className="text-sm text-gray-600 mt-1">
                  Essential cookies that keep you logged in and secure your account. These cannot 
                  be disabled as they are required for the service to function.
                </p>
              </div>
              
              <div className="border-l-4 border-indigo-500 pl-4 py-2 bg-gray-50 rounded-r">
                <h3 className="font-semibold text-gray-900">Functional Cookies</h3>
                <p className="text-sm text-gray-600 mt-1">
                  Remember your preferences like language settings, theme choices, and customization 
                  options to provide a personalized experience.
                </p>
              </div>
              
              <div className="border-l-4 border-indigo-500 pl-4 py-2 bg-gray-50 rounded-r">
                <h3 className="font-semibold text-gray-900">Analytics Cookies</h3>
                <p className="text-sm text-gray-600 mt-1">
                  Help us understand how visitors interact with our website by collecting information 
                  about page visits, time spent, and navigation patterns. We use Google Analytics 
                  for this purpose.
                </p>
              </div>
              
              <div className="border-l-4 border-indigo-500 pl-4 py-2 bg-gray-50 rounded-r">
                <h3 className="font-semibold text-gray-900">Marketing Cookies</h3>
                <p className="text-sm text-gray-600 mt-1">
                  Used to track visitors across websites to display relevant advertisements and measure 
                  the effectiveness of our marketing campaigns.
                </p>
              </div>
            </div>
          </section>

          <section className="mb-8">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Third-Party Cookies</h2>
            <p className="text-gray-600 leading-relaxed mb-4">
              We use the following third-party services that may set cookies:
            </p>
            <ul className="list-disc pl-6 space-y-2 text-gray-600">
              <li>
                <strong className="text-gray-900">Google Analytics:</strong> Used to analyze website 
                traffic and user behavior. You can opt-out using the{" "}
                <a 
                  href="https://tools.google.com/dlpage/gaoptout" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-indigo-600 hover:underline"
                >
                  Google Analytics Opt-out Browser Add-on
                </a>
              </li>
              <li>
                <strong className="text-gray-900">Razorpay:</strong> Our payment processor may set 
                cookies for fraud prevention and secure payment processing
              </li>
              <li>
                <strong className="text-gray-900">Firebase:</strong> Used for authentication and 
                real-time data synchronization
              </li>
            </ul>
          </section>

          <section className="mb-8">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Cookie Control Options</h2>
            <p className="text-gray-600 leading-relaxed mb-4">
              You can control and manage cookies in several ways:
            </p>
            <ul className="list-disc pl-6 space-y-2 text-gray-600">
              <li>
                <strong className="text-gray-900">Browser Settings:</strong> Most browsers allow you 
                to view, delete, and block cookies through settings. Check your browser's help section 
                for instructions.
              </li>
              <li>
                <strong className="text-gray-900">Opt-Out Links:</strong> Use the opt-out links 
                provided by third-party services like Google Analytics.
              </li>
              <li>
                <strong className="text-gray-900">Device Settings:</strong> Mobile devices typically 
                provide settings to limit ad tracking and manage cookies.
              </li>
              <li>
                <strong className="text-gray-900">Cookie Banner:</strong> Use our cookie consent 
                banner to manage your preferences when you first visit our site.
              </li>
            </ul>
            <p className="text-gray-600 leading-relaxed mt-4">
              Note: Disabling certain cookies may affect the functionality of Capella Pro and limit 
              your ability to use some features.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Cookie Duration</h2>
            <ul className="list-disc pl-6 space-y-2 text-gray-600">
              <li>
                <strong className="text-gray-900">Session Cookies:</strong> Temporary cookies that expire 
                when you close your browser.
              </li>
              <li>
                <strong className="text-gray-900">Persistent Cookies:</strong> Remain on your device for 
                a set period (typically 30 days to 2 years) or until you delete them.
              </li>
              <li>
                <strong className="text-gray-900">Authentication Cookies:</strong> Typically expire after 
                30 days of inactivity or when you explicitly log out.
              </li>
            </ul>
          </section>

          <section className="mb-8">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Updates to This Policy</h2>
            <p className="text-gray-600 leading-relaxed">
              We may update this Cookie Policy from time to time to reflect changes in technology, 
              legislation, or our data practices. Any changes will be posted on this page with an 
              updated revision date.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Contact Us</h2>
            <p className="text-gray-600 leading-relaxed">
              If you have any questions about our use of cookies, please contact us at:{" "}
              <a href="mailto:privacy@capellapro.com" className="text-indigo-600 hover:underline">
                privacy@capellapro.com
              </a>
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}
