import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Privacy Policy — Capella Pro",
  description: "Learn how Capella Pro collects, uses, and protects your personal information.",
};

export default function PrivacyPage() {
  return (
    <div className="py-12 sm:py-16">
      <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
        <div className="mb-8 border-b border-gray-200 pb-8">
          <h1 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">
            Privacy Policy
          </h1>
          <p className="mt-2 text-sm text-gray-500">
            Last Updated: November 27, 2025
          </p>
        </div>

        <div className="prose prose-gray max-w-none">
          <section className="mb-8">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Introduction</h2>
            <p className="text-gray-600 leading-relaxed">
              Capella Pro ("we", "us", or "our") operates the Capella Pro AI Productivity Suite. 
              This Privacy Policy explains how we collect, use, and protect your personal information 
              when you use our services.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Information We Collect</h2>
            <p className="text-gray-600 leading-relaxed mb-4">
              We collect the following types of information:
            </p>
            <ul className="list-disc pl-6 space-y-2 text-gray-600">
              <li>
                <strong className="text-gray-900">Personal Information:</strong> Name, email address, 
                payment details, and account credentials when you register or make purchases.
              </li>
              <li>
                <strong className="text-gray-900">Usage Data:</strong> Information about how you interact 
                with our features, including task management data, calendar entries, notes, and financial records.
              </li>
              <li>
                <strong className="text-gray-900">Technical Data:</strong> IP address, browser type, 
                device information, and cookies to improve your experience.
              </li>
            </ul>
          </section>

          <section className="mb-8">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Data Storage</h2>
            <p className="text-gray-600 leading-relaxed">
              Your data is securely stored using Firebase infrastructure located in Asia-South1 region. 
              We implement industry-standard security measures to protect your information from unauthorized 
              access, alteration, or destruction.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">How We Use Your Information</h2>
            <p className="text-gray-600 leading-relaxed mb-4">
              We use your information for the following purposes:
            </p>
            <ul className="list-disc pl-6 space-y-2 text-gray-600">
              <li>To provide and maintain the Capella Pro services</li>
              <li>To process payments securely via Razorpay</li>
              <li>To send you updates, newsletters, and marketing communications (with your consent)</li>
              <li>To improve our platform based on usage patterns and feedback</li>
              <li>To provide customer support and respond to inquiries</li>
            </ul>
          </section>

          <section className="mb-8">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Payment Processing</h2>
            <p className="text-gray-600 leading-relaxed">
              We use Razorpay for payment processing. When you make a payment, your payment information 
              is processed directly by Razorpay according to their{" "}
              <a href="https://razorpay.com/privacy/" target="_blank" rel="noopener noreferrer" className="text-indigo-600 hover:underline">
                Privacy Policy
              </a>. We do not store your complete credit card information on our servers.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Data Security</h2>
            <p className="text-gray-600 leading-relaxed">
              We take the security of your data seriously and implement:
            </p>
            <ul className="list-disc pl-6 space-y-2 text-gray-600 mt-4">
              <li>Industry-standard encryption (SSL/TLS) for data in transit</li>
              <li>Secure payment processing through Razorpay's PCI-DSS compliant infrastructure</li>
              <li>Regular security audits and vulnerability assessments</li>
              <li>Access controls and authentication measures</li>
            </ul>
          </section>

          <section className="mb-8">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Your Rights (GDPR Compliance)</h2>
            <p className="text-gray-600 leading-relaxed mb-4">
              You have the following rights regarding your personal data:
            </p>
            <ul className="list-disc pl-6 space-y-2 text-gray-600">
              <li>Access and receive a copy of your personal data</li>
              <li>Correct inaccurate or incomplete information</li>
              <li>Request deletion of your personal data</li>
              <li>Opt-out of marketing communications at any time</li>
              <li>Export your data in a portable format</li>
              <li>Withdraw consent for data processing</li>
            </ul>
          </section>

          <section className="mb-8">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Data Deletion</h2>
            <p className="text-gray-600 leading-relaxed">
              To request deletion of your personal data, please contact us at{" "}
              <a href="mailto:support@capellapro.co" className="text-indigo-600 hover:underline">
                support@capellapro.co
              </a>. We will process your request within 30 days and confirm deletion via email.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Contact Us</h2>
            <p className="text-gray-600 leading-relaxed">
              If you have any questions about this Privacy Policy, please contact us at:{" "}
              <a href="mailto:support@capellapro.co" className="text-indigo-600 hover:underline">
                support@capellapro.co
              </a>
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}
