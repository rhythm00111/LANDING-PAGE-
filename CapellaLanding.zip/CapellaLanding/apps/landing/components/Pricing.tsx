import Link from "next/link";
import { Check } from "lucide-react";

const plans = [
  {
    id: "free",
    name: "Free",
    price: "0",
    currency: "₹",
    period: "/month",
    description: "Perfect for getting started",
    features: [
      "AI Dashboard (Basic)",
      "Task Management (10 tasks)",
      "Calendar sync",
      "Basic Notes",
      "Community support",
    ],
    cta: "Start Free",
    popular: false,
  },
  {
    id: "pro",
    name: "Pro",
    price: "499",
    currency: "₹",
    period: "/month",
    description: "Best for professionals",
    features: [
      "Everything in Free",
      "Unlimited AI features",
      "AI Finance tracking",
      "CRM (1000 contacts)",
      "AI Templates library",
      "Whiteboard collaboration",
      "Focus Mode",
      "Priority support",
    ],
    cta: "Get Pro",
    popular: true,
  },
  {
    id: "enterprise",
    name: "Enterprise",
    price: "Contact",
    currency: "",
    period: "",
    description: "For large organizations",
    features: [
      "Everything in Pro",
      "Unlimited everything",
      "Custom integrations",
      "Dedicated account manager",
      "SLA guarantee",
      "Advanced security",
      "Custom training",
      "24/7 phone support",
    ],
    cta: "Contact Sales",
    popular: false,
  },
];

export default function Pricing() {
  return (
    <section className="bg-gray-50 py-20 sm:py-28" id="pricing" data-testid="section-pricing">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl" data-testid="text-pricing-title">
            Simple, Transparent Pricing
          </h2>
          <p className="mt-4 text-lg text-gray-600" data-testid="text-pricing-description">
            Choose the plan that fits your needs. Upgrade or downgrade anytime.
          </p>
        </div>

        <div className="mt-16 grid gap-8 lg:grid-cols-3">
          {plans.map((plan) => (
            <div
              key={plan.id}
              className={`relative flex flex-col rounded-2xl bg-white p-8 shadow-sm ${
                plan.popular
                  ? "ring-2 ring-indigo-600 shadow-lg"
                  : "border border-gray-200"
              }`}
              data-testid={`card-pricing-${plan.id}`}
            >
              {plan.popular && (
                <span className="absolute -top-4 left-1/2 -translate-x-1/2 rounded-full bg-indigo-600 px-4 py-1 text-sm font-medium text-white" data-testid="badge-popular">
                  Most Popular
                </span>
              )}
              <div>
                <h3 className="text-xl font-semibold text-gray-900" data-testid={`text-plan-name-${plan.id}`}>
                  {plan.name}
                </h3>
                <p className="mt-1 text-sm text-gray-500" data-testid={`text-plan-desc-${plan.id}`}>{plan.description}</p>
                <div className="mt-4 flex items-baseline gap-1" data-testid={`text-plan-price-${plan.id}`}>
                  <span className="text-sm text-gray-500">{plan.currency}</span>
                  <span className="text-4xl font-bold text-gray-900">
                    {plan.price}
                  </span>
                  <span className="text-sm text-gray-500">{plan.period}</span>
                </div>
              </div>
              <ul className="mt-8 flex-1 space-y-3">
                {plan.features.map((feature, index) => (
                  <li key={index} className="flex items-start gap-3" data-testid={`text-feature-${plan.id}-${index}`}>
                    <Check className="mt-0.5 h-5 w-5 shrink-0 text-indigo-600" />
                    <span className="text-sm text-gray-600">{feature}</span>
                  </li>
                ))}
              </ul>
              <Link
                href="/contact"
                className={`mt-8 block w-full rounded-lg py-3 text-center text-sm font-medium transition-colors ${
                  plan.popular
                    ? "bg-indigo-600 text-white hover:bg-indigo-700"
                    : "border border-gray-300 text-gray-700 hover:bg-gray-50"
                }`}
                data-testid={`button-plan-${plan.id}`}
              >
                {plan.cta}
              </Link>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
