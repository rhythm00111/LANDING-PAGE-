import {
  LayoutDashboard,
  CheckSquare,
  Calendar,
  Wallet,
  FileText,
  Users,
  FileCode,
  PenTool,
  Focus,
} from "lucide-react";

const features = [
  {
    id: "dashboard",
    icon: LayoutDashboard,
    title: "AI Dashboard",
    description: "Central hub for all your productivity insights and analytics powered by AI.",
  },
  {
    id: "tasks",
    icon: CheckSquare,
    title: "AI Task Management",
    description: "Smart task organization with AI-driven prioritization and automation.",
  },
  {
    id: "calendar",
    icon: Calendar,
    title: "AI Calendar",
    description: "Intelligent scheduling that learns your preferences and optimizes your time.",
  },
  {
    id: "finance",
    icon: Wallet,
    title: "AI Finance",
    description: "Expense tracking and financial insights with AI-powered categorization.",
  },
  {
    id: "notes",
    icon: FileText,
    title: "AI Notes",
    description: "Smart note-taking with AI summarization and organization features.",
  },
  {
    id: "crm",
    icon: Users,
    title: "CRM",
    description: "Customer relationship management to track leads and grow your business.",
  },
  {
    id: "templates",
    icon: FileCode,
    title: "AI Templates",
    description: "Pre-built workflows and templates to accelerate your productivity.",
  },
  {
    id: "whiteboard",
    icon: PenTool,
    title: "Whiteboard",
    description: "Visual collaboration space for brainstorming and planning projects.",
  },
  {
    id: "focus",
    icon: Focus,
    title: "Focus Mode",
    description: "Distraction-free environment to maximize your deep work sessions.",
  },
];

export default function Features() {
  return (
    <section className="py-20 sm:py-28" id="features" data-testid="section-features">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl" data-testid="text-features-title">
            Everything You Need to Succeed
          </h2>
          <p className="mt-4 text-lg text-gray-600" data-testid="text-features-description">
            Nine powerful AI-driven tools designed to streamline your workflow and boost productivity.
          </p>
        </div>

        <div className="mt-16 grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {features.map((feature) => (
            <div
              key={feature.id}
              className="group rounded-xl border border-gray-200 bg-white p-6 shadow-sm transition-all duration-200 hover:-translate-y-1 hover:shadow-md"
              data-testid={`card-feature-${feature.id}`}
            >
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-indigo-100">
                <feature.icon className="h-6 w-6 text-indigo-600" />
              </div>
              <h3 className="mt-4 text-lg font-semibold text-gray-900" data-testid={`text-feature-title-${feature.id}`}>
                {feature.title}
              </h3>
              <p className="mt-2 text-sm text-gray-600" data-testid={`text-feature-desc-${feature.id}`}>
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
