import Link from "next/link";
import { ArrowRight, Users } from "lucide-react";

export default function Hero() {
  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-indigo-50 via-white to-purple-50" data-testid="section-hero">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_80%_50%_at_50%_-20%,rgba(120,119,198,0.15),transparent)]" />
      
      <div className="relative mx-auto max-w-7xl px-4 py-24 sm:px-6 sm:py-32 lg:px-8 lg:py-40">
        <div className="mx-auto max-w-3xl text-center">
          <span className="inline-flex items-center rounded-full bg-indigo-100 px-4 py-1.5 text-sm font-medium text-indigo-700" data-testid="badge-hero">
            AI Productivity Suite
          </span>
          
          <h1 className="mt-6 text-4xl font-bold tracking-tight text-gray-900 sm:text-5xl lg:text-6xl" data-testid="text-hero-title">
            Transform Your Productivity{" "}
            <span className="bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
              with AI
            </span>
          </h1>
          
          <p className="mt-6 text-lg leading-relaxed text-gray-600 sm:text-xl" data-testid="text-hero-description">
            The all-in-one AI-powered workspace that helps you manage tasks, 
            schedule meetings, track finances, and collaborate seamlessly. 
            Work smarter, not harder.
          </p>
          
          <div className="mt-10 flex flex-col items-center justify-center gap-4 sm:flex-row">
            <Link
              href="/#pricing"
              className="inline-flex w-full items-center justify-center rounded-lg bg-indigo-600 px-6 py-3 text-base font-medium text-white shadow-sm transition-colors hover:bg-indigo-700 sm:w-auto"
              data-testid="button-hero-getstarted"
            >
              Get Started Free
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
            <Link
              href="/#pricing"
              className="inline-flex w-full items-center justify-center rounded-lg border border-gray-300 bg-white px-6 py-3 text-base font-medium text-gray-700 shadow-sm transition-colors hover:bg-gray-50 sm:w-auto"
              data-testid="button-hero-pricing"
            >
              View Pricing
            </Link>
          </div>
          
          <div className="mt-10 flex items-center justify-center gap-2 text-sm text-gray-500" data-testid="text-hero-trust">
            <Users className="h-4 w-4" />
            <span>Trusted by 10,000+ professionals worldwide</span>
          </div>
        </div>
      </div>
    </section>
  );
}
