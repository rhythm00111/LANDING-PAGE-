import Link from "next/link";
import Image from "next/image";

const footerLinks = {
  product: [
    { label: "AI Dashboard", href: "/#features" },
    { label: "Task Management", href: "/#features" },
    { label: "AI Calendar", href: "/#features" },
    { label: "AI Finance", href: "/#features" },
    { label: "Pricing", href: "/#pricing" },
  ],
  legal: [
    { label: "Privacy Policy", href: "/privacy" },
    { label: "Terms of Service", href: "/terms" },
    { label: "Refund Policy", href: "/refund" },
    { label: "Cookie Policy", href: "/cookies" },
  ],
  company: [
    { label: "About Us", href: "/contact" },
    { label: "Contact", href: "/contact" },
    { label: "Verification", href: "/verification" },
  ],
};

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="border-t border-gray-100 bg-gray-50">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8 lg:py-16">
        <div className="grid gap-8 lg:grid-cols-4">
          <div className="lg:col-span-1">
            <Link href="/" className="flex items-center gap-2" aria-label="Capella Pro Home" data-testid="link-footer-logo">
              <Image
                src="/logo.png"
                alt="Capella Pro Logo"
                width={32}
                height={32}
                className="h-8 w-8"
                data-testid="img-footer-logo"
              />
              <span className="text-xl font-bold text-gray-900" data-testid="text-footer-brand">Capella Pro</span>
            </Link>
            <p className="mt-4 text-sm text-gray-600" data-testid="text-footer-description">
              The AI-powered productivity suite that helps you work smarter, 
              not harder. Transform your workflow today.
            </p>
          </div>

          <div>
            <h3 className="text-sm font-semibold text-gray-900">Product</h3>
            <ul className="mt-4 space-y-3">
              {footerLinks.product.map((link) => (
                <li key={link.label}>
                  <Link
                    href={link.href}
                    className="text-sm text-gray-600 transition-colors hover:text-gray-900"
                    data-testid={`link-footer-${link.label.toLowerCase().replace(/\s+/g, "-")}`}
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-semibold text-gray-900">Legal</h3>
            <ul className="mt-4 space-y-3">
              {footerLinks.legal.map((link) => (
                <li key={link.label}>
                  <Link
                    href={link.href}
                    className="text-sm text-gray-600 transition-colors hover:text-gray-900"
                    data-testid={`link-footer-${link.label.toLowerCase().replace(/\s+/g, "-")}`}
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-semibold text-gray-900">Company</h3>
            <ul className="mt-4 space-y-3">
              {footerLinks.company.map((link) => (
                <li key={link.label}>
                  <Link
                    href={link.href}
                    className="text-sm text-gray-600 transition-colors hover:text-gray-900"
                    data-testid={`link-footer-${link.label.toLowerCase().replace(/\s+/g, "-")}`}
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
            <div className="mt-6">
              <h4 className="text-sm font-semibold text-gray-900">Contact</h4>
              <p className="mt-2 text-sm text-gray-600" data-testid="text-footer-email">
                support@capellapro.com
              </p>
            </div>
          </div>
        </div>

        <div className="mt-12 border-t border-gray-200 pt-8">
          <p className="text-center text-sm text-gray-500" data-testid="text-copyright">
            © {currentYear} Capella Pro. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
